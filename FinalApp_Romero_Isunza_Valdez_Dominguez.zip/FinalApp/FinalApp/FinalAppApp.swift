//
//  FinalAppApp.swift
//  FinalApp
//
//  Created by Ruben Romero on 06/06/23.
//

import SwiftUI

@main
struct FinalAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
