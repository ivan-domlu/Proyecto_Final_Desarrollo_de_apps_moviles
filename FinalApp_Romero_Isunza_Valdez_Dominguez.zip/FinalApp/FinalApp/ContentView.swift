//
//  ContentView.swift
//  FinalApp
//
//  Created by Ruben Romero on 06/06/23.
//

import SwiftUI

struct HomeView: View {
    @State private var tasks: [Task] = []
    @State private var schedules: [Schedule] = []
    @State private var grades: [Grade] = []

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Tareas pendientes: \(tasks.filter { !$0.isCompleted }.count)")
                    .font(.title)
                    .foregroundColor(.blue)

                Text("Próxima clase: \(schedules.first?.subject ?? "N/A") a las \(schedules.first?.time ?? "N/A")")
                    .font(.title)
                    .foregroundColor(.green)

                Text("Calificación promedio: \(calculateAverageGrade())")
                    .font(.title)
                    .foregroundColor(.orange)
            }
            .padding()
            .onAppear(perform: loadData)
            .navigationTitle("Inicio")
        }
    }

    private func loadData() {
        loadTasks()
        loadSchedules()
        loadGrades()
    }
    
    private func loadTasks() {
        if let savedTasks = UserDefaults.standard.data(forKey: "tasks") {
            if let loadedTasks = try? JSONDecoder().decode([Task].self, from: savedTasks) {
                tasks = loadedTasks
            }
        }
    }
    
    private func loadSchedules() {
        if let savedSchedules = UserDefaults.standard.data(forKey: "schedules") {
            if let loadedSchedules = try? JSONDecoder().decode([Schedule].self, from: savedSchedules) {
                schedules = loadedSchedules
            }
        }
    }
    
    private func loadGrades() {
        if let savedGrades = UserDefaults.standard.data(forKey: "grades") {
            if let loadedGrades = try? JSONDecoder().decode([Grade].self, from: savedGrades) {
                grades = loadedGrades
            }
        }
    }
    
    private func calculateAverageGrade() -> String {
        var totalScore = 0.0
        for grade in grades {
            if let score = Double(grade.score) {
                totalScore += score
            }
        }
        
        let averageScore = grades.isEmpty ? 0 : totalScore / Double(grades.count)
        
        return String(format: "%.2f", averageScore)
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}


struct CalendarView: View {
    let daysInWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    let daysInMonth = Array(1...30) // Para simplificar, supondremos 30 días en el mes

    var columns: [GridItem] {
        [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())]
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                LazyVGrid(columns: columns, alignment: .center, spacing: 10) {
                    ForEach(daysInWeek, id: \.self) { day in
                        Text(day)
                            .font(.title2)
                            .fontWeight(.bold)
                    }
                    ForEach(daysInMonth, id: \.self) { day in
                        Text("\(day)")
                            .font(.title3)
                            .fontWeight(.semibold)
                    }
                }
                .padding()
            }
            .navigationTitle("Calendario")
        }
    }
}

struct CalendarView_Previews: PreviewProvider {
    static var previews: some View {
        CalendarView()
    }
}

struct GradesView: View {
    @State private var grades: [Grade] = []
    @State private var newGradeSubject: String = ""
    @State private var newGradeScore: String = ""
    @State private var isEditing = false
    @State private var currentEditGradeId: UUID?
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(grades) { grade in
                        HStack {
                            if isEditing && grade.id == currentEditGradeId {
                                VStack {
                                    TextField("Materia", text: $newGradeSubject)
                                    TextField("Calificación", text: $newGradeScore, onCommit: {
                                        if let index = grades.firstIndex(where: { $0.id == grade.id }) {
                                            grades[index].subject = newGradeSubject
                                            grades[index].score = newGradeScore
                                            saveGrades()
                                        }
                                        isEditing = false
                                        currentEditGradeId = nil
                                    })
                                }
                            } else {
                                Text("\(grade.subject): \(grade.score)")
                                    .font(.title2)
                            }
                        }
                        .onLongPressGesture {
                            isEditing = true
                            currentEditGradeId = grade.id
                            newGradeSubject = grade.subject
                            newGradeScore = grade.score
                        }
                    }
                    .onDelete(perform: delete)
                }
                
                HStack {
                    TextField("Materia", text: $newGradeSubject)
                    TextField("Calificación", text: $newGradeScore)
                    Button(action: addGrade, label: {
                        Text("Añadir")
                    })
                }
                .padding()
            }
            .navigationTitle("Calificaciones")
            .onAppear(perform: loadGrades)
        }
    }
    
    private func delete(at offsets: IndexSet) {
        grades.remove(atOffsets: offsets)
        saveGrades()
    }
    
    private func addGrade() {
        let newGrade = Grade(subject: newGradeSubject, score: newGradeScore)
        grades.append(newGrade)
        newGradeSubject = ""
        newGradeScore = ""
        saveGrades()
    }
    
    private func saveGrades() {
        if let encodedData = try? JSONEncoder().encode(grades) {
            UserDefaults.standard.set(encodedData, forKey: "grades")
        }
    }
    
    private func loadGrades() {
        if let savedGrades = UserDefaults.standard.data(forKey: "grades") {
            if let loadedGrades = try? JSONDecoder().decode([Grade].self, from: savedGrades) {
                grades = loadedGrades
            }
        }
    }
}

struct GradesView_Previews: PreviewProvider {
    static var previews: some View {
        GradesView()
    }
}

struct Grade: Identifiable, Codable {
    let id = UUID()
    var subject: String
    var score: String
}

struct ScheduleView: View {
    @State private var schedules: [Schedule] = []
    @State private var newScheduleSubject: String = ""
    @State private var newScheduleTime: String = ""
    @State private var isEditing = false
    @State private var currentEditScheduleId: UUID?
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(schedules) { schedule in
                        HStack {
                            if isEditing && schedule.id == currentEditScheduleId {
                                VStack {
                                    TextField("Materia", text: $newScheduleSubject)
                                    TextField("Hora", text: $newScheduleTime, onCommit: {
                                        if let index = schedules.firstIndex(where: { $0.id == schedule.id }) {
                                            schedules[index].subject = newScheduleSubject
                                            schedules[index].time = newScheduleTime
                                            saveSchedules()
                                        }
                                        isEditing = false
                                        currentEditScheduleId = nil
                                    })
                                }
                            } else {
                                Text("\(schedule.subject) - \(schedule.time)")
                                    .font(.title2)
                            }
                        }
                        .onLongPressGesture {
                            isEditing = true
                            currentEditScheduleId = schedule.id
                            newScheduleSubject = schedule.subject
                            newScheduleTime = schedule.time
                        }
                    }
                    .onDelete(perform: delete)
                }
                
                HStack {
                    TextField("Materia", text: $newScheduleSubject)
                    TextField("Hora", text: $newScheduleTime)
                    Button(action: addSchedule, label: {
                        Text("Añadir")
                    })
                }
                .padding()
            }
            .navigationTitle("Horario")
            .onAppear(perform: loadSchedules)
        }
    }
    
    private func delete(at offsets: IndexSet) {
        schedules.remove(atOffsets: offsets)
        saveSchedules()
    }
    
    private func addSchedule() {
        let newSchedule = Schedule(subject: newScheduleSubject, time: newScheduleTime)
        schedules.append(newSchedule)
        newScheduleSubject = ""
        newScheduleTime = ""
        saveSchedules()
    }
    
    private func saveSchedules() {
        if let encodedData = try? JSONEncoder().encode(schedules) {
            UserDefaults.standard.set(encodedData, forKey: "schedules")
        }
    }
    
    private func loadSchedules() {
        if let savedSchedules = UserDefaults.standard.data(forKey: "schedules") {
            if let loadedSchedules = try? JSONDecoder().decode([Schedule].self, from: savedSchedules) {
                schedules = loadedSchedules
            }
        }
    }
}

struct ScheduleView_Previews: PreviewProvider {
    static var previews: some View {
        ScheduleView()
    }
}

struct Schedule: Identifiable, Codable {
    let id = UUID()
    var subject: String
    var time: String
}

struct TasksView: View {
    @State private var tasks: [Task] = []
    @State private var newTaskName: String = ""
    @State private var isEditing = false
    @State private var currentEditTaskId: UUID?
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(tasks) { task in
                        HStack {
                            if isEditing && task.id == currentEditTaskId {
                                TextField("Nombre de la tarea", text: $newTaskName, onCommit: {
                                    if let index = tasks.firstIndex(where: { $0.id == task.id }) {
                                        tasks[index].name = newTaskName
                                        saveTasks()
                                    }
                                    isEditing = false
                                    currentEditTaskId = nil
                                })
                            } else {
                                Text(task.name)
                                    .font(.title2)
                            }
                            
                            Spacer()
                            
                            Image(systemName: task.isCompleted ? "checkmark.square" : "square")
                                .resizable()
                                .frame(width: 24, height: 24)
                                .onTapGesture {
                                    if let index = tasks.firstIndex(where: { $0.id == task.id }) {
                                        tasks[index].isCompleted.toggle()
                                        saveTasks()
                                    }
                                }
                        }
                        .onLongPressGesture {
                            isEditing = true
                            currentEditTaskId = task.id
                            newTaskName = task.name
                        }
                    }
                    .onDelete(perform: delete)
                }
                
                HStack {
                    TextField("Nueva tarea", text: $newTaskName)
                    Button(action: addTask, label: {
                        Text("Añadir")
                    })
                }
                .padding()
            }
            .navigationTitle("Tareas")
            .onAppear(perform: loadTasks)
        }
    }
    
    private func delete(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
        saveTasks()
    }
    
    private func addTask() {
        let newTask = Task(name: newTaskName, isCompleted: false)
        tasks.append(newTask)
        newTaskName = ""
        saveTasks()
    }
    
    private func saveTasks() {
        if let encodedData = try? JSONEncoder().encode(tasks) {
            UserDefaults.standard.set(encodedData, forKey: "tasks")
        }
    }
    
    private func loadTasks() {
        if let savedTasks = UserDefaults.standard.data(forKey: "tasks") {
            if let loadedTasks = try? JSONDecoder().decode([Task].self, from: savedTasks) {
                tasks = loadedTasks
            }
        }
    }
}

struct TasksView_Previews: PreviewProvider {
    static var previews: some View {
        TasksView()
    }
}

struct Task: Identifiable, Codable {
    let id = UUID()
    var name: String
    var isCompleted: Bool
}



struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    VStack {
                        Image(systemName: "house.fill")
                        Text("Inicio")
                    }
                }
            
            CalendarView()
                .tabItem {
                    VStack {
                        Image(systemName: "calendar")
                        Text("Calendario")
                    }
                }
            
            ScheduleView()
                .tabItem {
                    VStack {
                        Image(systemName: "clock.fill")
                        Text("Horario")
                    }
                }
            
            GradesView()
                .tabItem {
                    VStack {
                        Image(systemName: "chart.bar.fill")
                        Text("Calificaciones")
                    }
                }
            
            TasksView()
                .tabItem {
                    VStack {
                        Image(systemName: "text.badge.checkmark")
                        Text("Tareas")
                    }
                }
        }
        .accentColor(.black)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
