//
//  FinalProjectApp.swift
//  FinalProject
//
//  Created by iOS Lab on 06/06/23.
//

import SwiftUI

@main
struct FinalProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
