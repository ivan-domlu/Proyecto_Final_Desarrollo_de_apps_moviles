//
//  ContentView.swift
//  FinalApp
//
//  Created by Ruben Romero on 06/06/23.
//

import SwiftUI

struct HomeView: View {
    @State private var tasks: [Task] = []
    @State private var schedules: [Schedule] = []
    @State private var grades: [Grade] = []

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                VStack {
                    VStack {
                        Text("Tareas pendientes")
                            .font(.title)
                            .foregroundColor(.white)
                            .padding(.top, 5)
                        Text("\(tasks.filter { !$0.isCompleted }.count)")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                    }
                    .padding()
                }
                .frame(maxWidth: .infinity)
                .background(Color.blue)
                .cornerRadius(10)
                .shadow(radius: 5)

                VStack {
                    VStack {
                        Text("Próxima clase")
                            .font(.title)
                            .foregroundColor(.white)
                            .padding(.top, 5)
                        Text("\(schedules.first?.subject ?? "N/A")")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding(.top, 5)
                        Text("\(schedules.first?.time ?? "N/A")")
                            .font(.subheadline)
                            .foregroundColor(.white)
                            .padding(.top, 2)
                    }
                    .padding()
                }
                .frame(maxWidth: .infinity)
                .background(Color.green)
                .cornerRadius(10)
                .shadow(radius: 5)

                VStack {
                    VStack {
                        Text("Calificación promedio")
                            .font(.title)
                            .foregroundColor(.white)
                            .padding(.top, 5)
                        Text(calculateAverageGrade())
                            .font(.largeTitle)
                            .foregroundColor(.white)
                    }
                    .padding()

                    ZStack(alignment: .leading) {
                        Rectangle()
                            .foregroundColor(.gray)
                            .frame(height: 10)
                        Rectangle()
                            .foregroundColor(.white)
                            .frame(width: calculateAverageGradeBarWidth(), height: 10)
                    }
                    .cornerRadius(5)
                    .padding(.top, 5)
                    .frame(maxWidth: 300)

                    HStack {
                        Spacer()
                        Text("0")
                            .font(.subheadline)
                            .foregroundColor(.white)
                        Spacer()
                        Spacer()
                        Spacer()
                        Spacer()
                        Spacer()
                        Spacer()
                        Text("10")
                            .font(.subheadline)
                            .foregroundColor(.white)
                        Spacer()
                    }
                }
                .frame(maxWidth: .infinity)
                .background(Color.orange)
                .cornerRadius(10)
                .shadow(radius: 5)
            }
            .padding()
            .onAppear(perform: loadData)
            .navigationTitle("Inicio")
        }
    }

    private func loadData() {
        loadTasks()
        loadSchedules()
        loadGrades()
    }
    
    private func loadTasks() {
        if let savedTasks = UserDefaults.standard.data(forKey: "tasks") {
            if let loadedTasks = try? JSONDecoder().decode([Task].self, from: savedTasks) {
                tasks = loadedTasks
            }
        }
    }
    
    private func loadSchedules() {
        if let savedSchedules = UserDefaults.standard.data(forKey: "schedules") {
            if let loadedSchedules = try? JSONDecoder().decode([Schedule].self, from: savedSchedules) {
                schedules = loadedSchedules
            }
        }
    }
    
    private func loadGrades() {
        if let savedGrades = UserDefaults.standard.data(forKey: "grades") {
            if let loadedGrades = try? JSONDecoder().decode([Grade].self, from: savedGrades) {
                grades = loadedGrades
            }
        }
    }
    
    private func calculateAverageGrade() -> String {
        let totalScore = grades.reduce(0.0) { $0 + (Double($1.score) ?? 0) }
        let averageScore = grades.isEmpty ? 0 : totalScore / Double(grades.count)
        return String(format: "%.2f", averageScore)
    }
    
    private func calculateAverageGradeBarWidth() -> CGFloat {
        let maxWidth: CGFloat = 300
        let totalScore = grades.reduce(0.0) { $0 + (Double($1.score) ?? 0) }
        let averageScore = grades.isEmpty ? 0 : totalScore / Double(grades.count)
        return maxWidth * CGFloat(averageScore / 10.0)
    }
}



struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}


struct CalendarView: View {
    @State private var selectedDate: Date = Date()
    @State private var events: [String: [String]] = [
        "2023-06-06": ["Evento 1"],
        "2023-06-10": ["Evento 3"],
        "2023-06-15": ["Evento 4", "Evento 5"]
    ]
    @State private var newEvent: String = ""
    
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()

    var body: some View {
        NavigationView {
            VStack {
                Text(getFormattedDate())
                                    .font(.system(size: 28))
                                    .bold()
                                    .foregroundColor(Color.accentColor)
                                    .padding()
                                    .animation(.spring(), value: selectedDate)
                                    .frame(maxWidth: .infinity)                    .font(.system(size: 28))
                    .bold()
                    .foregroundColor(Color.accentColor)
                    .padding()
                    .animation(.spring(), value: selectedDate)
                    .frame(width: 500)
                Divider().frame(height: 1)
                DatePicker("Select Date", selection: $selectedDate, displayedComponents: [.date])
                    .padding(.horizontal)
                    .datePickerStyle(.graphical)
                Divider()
                if let eventsForSelectedDate = events[dateFormatter.string(from: selectedDate)] {
                    VStack(alignment: .leading) {
                        Text("Eventos para el día seleccionado:")
                            .font(.headline)
                            .padding(.vertical, 10)
                        ForEach(eventsForSelectedDate, id: \.self) { event in
                            Text("- \(event)")
                        }
                    }
                    .frame(maxHeight: 20)
                    .padding(.horizontal)
                }
                VStack(alignment: .leading) {
                    Text("Agregar evento:")
                        .font(.headline)
                        .padding(.vertical, 10)
                    TextField("Ingrese un evento", text: $newEvent)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal)
                    Button(action: addEvent) {
                        Text("Agregar")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.accentColor)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal)
                }
                Spacer()
            }
            .padding(.vertical, 100)
            .navigationTitle("Calendario")
        }
    }

    func addEvent() {
        guard !newEvent.isEmpty else {
            return
        }
        
        let dateString = dateFormatter.string(from: selectedDate)
        if var existingEvents = events[dateString] {
            existingEvents.append(newEvent)
            events[dateString] = existingEvents
        } else {
            events[dateString] = [newEvent]
        }
        
        newEvent = ""
    }
    private func getFormattedDate() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "d MMMM yyyy"
        return dateFormatter.string(from: selectedDate)
    }
}
struct CalendarView_Previews: PreviewProvider {
    static var previews: some View {
        CalendarView()
    }
}

struct GradesView: View {
    @State private var grades: [Grade] = []
    @State private var newGradeSubject: String = ""
    @State private var newGradeScore: String = ""
    @State private var isEditing = false
    @State private var currentEditGradeId: UUID?
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(grades) { grade in
                        HStack {
                            if isEditing && grade.id == currentEditGradeId {
                                VStack {
                                    TextField("Materia", text: $newGradeSubject)
                                    TextField("Calificación", text: $newGradeScore, onCommit: {
                                        if let index = grades.firstIndex(where: { $0.id == grade.id }) {
                                            grades[index].subject = newGradeSubject
                                            grades[index].score = newGradeScore
                                            saveGrades()
                                        }
                                        isEditing = false
                                        currentEditGradeId = nil
                                    })
                                }
                            } else {
                                Text("\(grade.subject): \(grade.score)")
                                    .font(.title2)
                            }
                        }
                        .onLongPressGesture {
                            isEditing = true
                            currentEditGradeId = grade.id
                            newGradeSubject = grade.subject
                            newGradeScore = grade.score
                        }
                    }
                    .onDelete(perform: delete)
                }
                
                HStack {
                    TextField("Materia", text: $newGradeSubject)
                    TextField("Calificación", text: $newGradeScore)
                    Button(action: addGrade, label: {
                        Text("Añadir")
                    })
                }
                .padding()
            }
            .navigationTitle("Calificaciones")
            .onAppear(perform: loadGrades)
        }
    }
    
    private func delete(at offsets: IndexSet) {
        grades.remove(atOffsets: offsets)
        saveGrades()
    }
    
    private func addGrade() {
        let newGrade = Grade(subject: newGradeSubject, score: newGradeScore)
        grades.append(newGrade)
        newGradeSubject = ""
        newGradeScore = ""
        saveGrades()
    }
    
    private func saveGrades() {
        if let encodedData = try? JSONEncoder().encode(grades) {
            UserDefaults.standard.set(encodedData, forKey: "grades")
        }
    }
    
    private func loadGrades() {
        if let savedGrades = UserDefaults.standard.data(forKey: "grades") {
            if let loadedGrades = try? JSONDecoder().decode([Grade].self, from: savedGrades) {
                grades = loadedGrades
            }
        }
    }
}

struct GradesView_Previews: PreviewProvider {
    static var previews: some View {
        GradesView()
    }
}

struct Grade: Identifiable, Codable {
    var id = UUID()
    var subject: String
    var score: String
}

struct ScheduleView: View {
    @State private var schedules: [Schedule] = []
    @State private var newScheduleSubject: String = ""
    @State private var newScheduleTime: String = ""
    @State private var isEditing = false
    @State private var currentEditScheduleId: UUID?
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(schedules) { schedule in
                        HStack {
                            if isEditing && schedule.id == currentEditScheduleId {
                                VStack {
                                    TextField("Materia", text: $newScheduleSubject)
                                    TextField("Hora", text: $newScheduleTime, onCommit: {
                                        if let index = schedules.firstIndex(where: { $0.id == schedule.id }) {
                                            schedules[index].subject = newScheduleSubject
                                            schedules[index].time = newScheduleTime
                                            saveSchedules()
                                        }
                                        isEditing = false
                                        currentEditScheduleId = nil
                                    })
                                }
                            } else {
                                Text("\(schedule.subject) - \(schedule.time)")
                                    .font(.title2)
                            }
                        }
                        .onLongPressGesture {
                            isEditing = true
                            currentEditScheduleId = schedule.id
                            newScheduleSubject = schedule.subject
                            newScheduleTime = schedule.time
                        }
                    }
                    .onDelete(perform: delete)
                }
                
                HStack {
                    TextField("Materia", text: $newScheduleSubject)
                    TextField("Hora", text: $newScheduleTime)
                    Button(action: addSchedule, label: {
                        Text("Añadir")
                    })
                }
                .padding()
            }
            .navigationTitle("Horario")
            .onAppear(perform: loadSchedules)
        }
    }
    
    private func delete(at offsets: IndexSet) {
        schedules.remove(atOffsets: offsets)
        saveSchedules()
    }
    
    private func addSchedule() {
        let newSchedule = Schedule(subject: newScheduleSubject, time: newScheduleTime)
        schedules.append(newSchedule)
        newScheduleSubject = ""
        newScheduleTime = ""
        saveSchedules()
    }
    
    private func saveSchedules() {
        if let encodedData = try? JSONEncoder().encode(schedules) {
            UserDefaults.standard.set(encodedData, forKey: "schedules")
        }
    }
    
    private func loadSchedules() {
        if let savedSchedules = UserDefaults.standard.data(forKey: "schedules") {
            if let loadedSchedules = try? JSONDecoder().decode([Schedule].self, from: savedSchedules) {
                schedules = loadedSchedules
            }
        }
    }
}

struct ScheduleView_Previews: PreviewProvider {
    static var previews: some View {
        ScheduleView()
    }
}

struct Schedule: Identifiable, Codable {
    var id = UUID()
    var subject: String
    var time: String
}

struct TasksView: View {
    @State private var tasks: [Task] = []
    @State private var newTaskName: String = ""
    @State private var isEditing = false
    @State private var currentEditTaskId: UUID?
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(tasks) { task in
                        HStack {
                            if isEditing && task.id == currentEditTaskId {
                                TextField("Nombre de la tarea", text: $newTaskName, onCommit: {
                                    if let index = tasks.firstIndex(where: { $0.id == task.id }) {
                                        tasks[index].name = newTaskName
                                        saveTasks()
                                    }
                                    isEditing = false
                                    currentEditTaskId = nil
                                })
                            } else {
                                Text(task.name)
                                    .font(.title2)
                            }
                            
                            Spacer()
                            
                            Image(systemName: task.isCompleted ? "checkmark.square" : "square")
                                .resizable()
                                .frame(width: 24, height: 24)
                                .onTapGesture {
                                    if let index = tasks.firstIndex(where: { $0.id == task.id }) {
                                        tasks[index].isCompleted.toggle()
                                        saveTasks()
                                    }
                                }
                        }
                        .onLongPressGesture {
                            isEditing = true
                            currentEditTaskId = task.id
                            newTaskName = task.name
                        }
                    }
                    .onDelete(perform: delete)
                }
                
                HStack {
                    TextField("Nueva tarea", text: $newTaskName)
                    Button(action: addTask, label: {
                        Text("Añadir")
                    })
                }
                .padding()
            }
            .navigationTitle("Tareas")
            .onAppear(perform: loadTasks)
        }
    }
    
    private func delete(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
        saveTasks()
    }
    
    private func addTask() {
        let newTask = Task(name: newTaskName, isCompleted: false)
        tasks.append(newTask)
        newTaskName = ""
        saveTasks()
    }
    
    private func saveTasks() {
        if let encodedData = try? JSONEncoder().encode(tasks) {
            UserDefaults.standard.set(encodedData, forKey: "tasks")
        }
    }
    
    private func loadTasks() {
        if let savedTasks = UserDefaults.standard.data(forKey: "tasks") {
            if let loadedTasks = try? JSONDecoder().decode([Task].self, from: savedTasks) {
                tasks = loadedTasks
            }
        }
    }
}

struct TasksView_Previews: PreviewProvider {
    static var previews: some View {
        TasksView()
    }
}

struct Task: Identifiable, Codable {
    var id = UUID()
    var name: String
    var isCompleted: Bool
}



struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    VStack {
                        Image(systemName: "house.fill")
                        Text("Inicio")
                    }
                }
            
            CalendarView()
                .tabItem {
                    VStack {
                        Image(systemName: "calendar")
                        Text("Calendario")
                    }
                }
            
            ScheduleView()
                .tabItem {
                    VStack {
                        Image(systemName: "clock.fill")
                        Text("Horario")
                    }
                }
            
            GradesView()
                .tabItem {
                    VStack {
                        Image(systemName: "chart.bar.fill")
                        Text("Calificaciones")
                    }
                }
            
            TasksView()
                .tabItem {
                    VStack {
                        Image(systemName: "text.badge.checkmark")
                        Text("Tareas")
                    }
                }
        }
        .accentColor(.black)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
